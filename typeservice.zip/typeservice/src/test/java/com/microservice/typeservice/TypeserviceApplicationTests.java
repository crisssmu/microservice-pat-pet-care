package com.microservice.typeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TypeserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
